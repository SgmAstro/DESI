def abs_mag(magnitude, distmod, k, E):
    return magnitude - distmod - k - E
    
