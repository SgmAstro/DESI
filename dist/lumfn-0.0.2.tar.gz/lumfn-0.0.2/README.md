# DESI
[![Python Package using Conda](https://github.com/SgmAstro/DESI/actions/workflows/python-package-conda.yml/badge.svg)](https://github.com/SgmAstro/DESI/actions/workflows/python-package-conda.yml)


Place for PhD Work Code
