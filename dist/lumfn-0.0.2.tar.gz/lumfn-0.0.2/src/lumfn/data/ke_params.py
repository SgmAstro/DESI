Qall          = 0.97
Qred          = 0.80
Qblue         = 2.12
redblue_split = 0.63
