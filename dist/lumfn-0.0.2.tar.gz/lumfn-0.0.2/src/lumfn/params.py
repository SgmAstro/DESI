sphere_radius            = 8.0
fillfactor_threshold     = 0.90

# Should match loop in bin/rand_pipeline, bin/rand_ddp1_pipeline.
oversample_nrealisations = 24
